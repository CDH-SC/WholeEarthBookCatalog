node ./loc_import/step1.js;
node ./loc_import/step2.js;
