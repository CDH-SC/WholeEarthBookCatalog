page naming conventions:

Must contain "dhc-" as a prefix. I know this seems silly, but it is needed for
routing and grabbing the correct html for a page. 

Personal preference instead of camelCase, I would prefer all lowercase with
dashes. This makes the most sense to me since we need to prefix pages with 'dhc-'.

so helpPage -> help-page (and really, dhc-help-page).